
  export const questions : string[] = [
    "Can you code in Ruby?",
    "Can you code in JavaScript?",
    "Can you code in Swift?",
    "Can you code in Java?",
    "Can you code in C#?"
  ];